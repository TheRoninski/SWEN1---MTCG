package at.ron.mtcg.dal;

import at.ron.mtcg.model.Users;

import java.util.ArrayList;

public class UserRepository {
    private static UserRepository Instance = null;

    public UserRepository() {
    }

    public static UserRepository getInstance() {
        if (Instance == null) {
            Instance = new UserRepository();
        }
        return Instance;
    }

    private ArrayList<Users> users = new ArrayList<>();

    public void register(Users users) {
        for(var user:users.values)
    }
}
