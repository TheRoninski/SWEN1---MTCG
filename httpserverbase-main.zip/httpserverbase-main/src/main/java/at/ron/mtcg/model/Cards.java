package at.ron.mtcg.model;

public class Cards {
    public String ID;
    public String name;
    public int dmg;
}
