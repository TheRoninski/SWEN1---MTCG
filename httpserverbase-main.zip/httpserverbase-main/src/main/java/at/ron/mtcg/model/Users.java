package at.ron.mtcg.model;

public class Users {
    private String username;
    private String password;
    private String token;

    public Users(UserCredentials credentials) {
        username = credentials.username;
        password = credentials.password;
    }
}
