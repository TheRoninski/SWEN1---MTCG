package at.ron.httpserver.http;

public enum Method {
    GET,
    POST,
    PUT,
    PATCH,
    DELETE,
}
